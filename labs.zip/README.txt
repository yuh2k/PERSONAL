Python 3 standard library only.
1. python3 -m unittest discover -s starter -v (expected failures until implemented)
2. Implement starter/batcher.py and starter/features.py without weakening tests.
3. python3 -m unittest discover -s reference -v (10 tests pass)
These are teaching exercises, not production online infrastructure.
